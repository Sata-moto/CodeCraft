#pragma once

#include <cmath>
#include <queue>
#include <vector>
#include <string>
#include <cstdio>
#include <cstdlib>
#include <algorithm>

using namespace std;
const int N = 102;

const double Pi = 3.1415926536;
